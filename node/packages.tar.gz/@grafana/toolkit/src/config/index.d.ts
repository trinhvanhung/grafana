export { CustomWebpackConfigurationGetter, WebpackConfigurationOptions } from './webpack.plugin.config';
