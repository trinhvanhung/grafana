export declare const getPluginId: () => string;
