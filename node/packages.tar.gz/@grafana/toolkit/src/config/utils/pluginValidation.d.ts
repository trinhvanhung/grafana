import { PluginMeta } from '@grafana/data';
export declare const validatePluginJson: (pluginJson: any) => void;
export declare const getPluginJson: (path: string) => PluginMeta;
