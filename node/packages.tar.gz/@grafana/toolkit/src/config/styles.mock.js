// Mock for handling stylesheet file imports in tests
// https://jestjs.io/docs/en/webpack.html#handling-static-assets

module.exports = {};
