import { Task } from './task';
interface PackageBuildOptions {
    scope: string;
}
export declare const buildPackageTask: Task<PackageBuildOptions>;
export {};
