import { Task } from '../task';
interface BundeManagedOptions {
}
export declare const bundleManagedTask: Task<BundeManagedOptions>;
export {};
