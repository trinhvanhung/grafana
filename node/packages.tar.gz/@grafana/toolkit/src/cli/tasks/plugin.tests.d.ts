import { Task } from './task';
import { PluginTestOptions } from './plugin/tests';
export declare const pluginTestTask: Task<PluginTestOptions>;
