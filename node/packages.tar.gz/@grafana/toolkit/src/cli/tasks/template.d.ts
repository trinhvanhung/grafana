import { Task } from './task';
interface TemplateOptions {
}
export declare const templateTask: Task<TemplateOptions>;
export {};
