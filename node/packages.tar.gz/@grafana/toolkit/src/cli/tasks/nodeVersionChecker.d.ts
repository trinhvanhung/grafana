import { Task } from './task';
interface NodeVersionCheckerOptions {
}
export declare const nodeVersionFiles: string[];
export declare const nodeVersionCheckerTask: Task<NodeVersionCheckerOptions>;
export {};
