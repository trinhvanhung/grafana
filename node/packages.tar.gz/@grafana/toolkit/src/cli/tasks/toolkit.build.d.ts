import { Task } from './task';
interface ToolkitBuildOptions {
}
export declare const toolkitBuildTask: Task<ToolkitBuildOptions>;
export {};
