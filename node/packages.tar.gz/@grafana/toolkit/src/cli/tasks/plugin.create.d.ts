import { Task } from './task';
interface PluginCreateOptions {
    name?: string;
}
export declare const pluginCreateTask: Task<PluginCreateOptions>;
export {};
