import { Task } from './task';
interface CherryPickOptions {
    enterprise: boolean;
}
export declare const cherryPickTask: Task<CherryPickOptions>;
export {};
