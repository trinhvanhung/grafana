import { Task } from './task';
interface ChangelogOptions {
    milestone: string;
}
export declare const changelogTask: Task<ChangelogOptions>;
export {};
