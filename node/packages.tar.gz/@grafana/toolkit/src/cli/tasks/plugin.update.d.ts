import { Task } from './task';
interface UpdatePluginTask {
}
export declare const pluginUpdateTask: Task<UpdatePluginTask>;
export {};
