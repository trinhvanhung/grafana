import { Task } from './task';
import { PluginBundleOptions } from './plugin/bundle';
export declare const pluginDevTask: Task<PluginBundleOptions>;
