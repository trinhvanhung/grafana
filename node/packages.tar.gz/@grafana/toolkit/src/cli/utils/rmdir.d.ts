/**
 * Remove directory recursively
 * Ref https://stackoverflow.com/a/42505874
 */
export declare const rmdir: (dirPath: string) => void;
