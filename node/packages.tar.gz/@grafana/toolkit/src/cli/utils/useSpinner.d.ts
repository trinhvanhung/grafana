export declare const useSpinner: (label: string, fn: () => Promise<any>, killProcess?: boolean) => Promise<void>;
