export declare const pascalCase: (string?: string | undefined) => string;
