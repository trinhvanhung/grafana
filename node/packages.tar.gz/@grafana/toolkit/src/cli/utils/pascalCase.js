"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.pascalCase = void 0;
var tslib_1 = require("tslib");
var lodash_1 = tslib_1.__importDefault(require("lodash"));
exports.pascalCase = lodash_1.default.flow(lodash_1.default.camelCase, lodash_1.default.upperFirst);
//# sourceMappingURL=pascalCase.js.map