export { componentTpl } from './component.tsx.template';
export { storyTpl } from './story.tsx.template';
export { docsTpl } from './docs.mdx.template';
export { testTpl } from './component.test.tsx.template';
