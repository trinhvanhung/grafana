"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.componentTpl = void 0;
exports.componentTpl = "import React, { FC } from 'react';\n\nexport interface Props {};\n\nexport const <%= name %>: FC<Props> = (props) => {\n  return (\n    <div>Hello world!</div>\n  )\n};\n";
//# sourceMappingURL=component.tsx.template.js.map