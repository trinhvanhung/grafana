import { WorkflowInfo, CoverageInfo, TestResultsInfo } from './types';
export declare const agregateWorkflowInfo: () => WorkflowInfo;
export declare const agregateCoverageInfo: () => CoverageInfo[];
export declare const agregateTestInfo: () => TestResultsInfo[];
